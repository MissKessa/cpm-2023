package uo.cpm.examen.service;

import uo.cpm.examen.model.Catalogo;
import uo.cpm.examen.model.Juego;
import uo.cpm.examen.model.Premio;
import uo.cpm.examen.model.Tablero;

public class GatoRaton {
	private Juego juego = new Juego();
	private Catalogo catalogo = new Catalogo();
	
	public void inicializar() {
		juego.inicializar();
	}
	
	public int descubrirCasilla(int casilla) {
		return juego.descubrirCasilla(casilla);
	}
	
	public int getPuntuacion() {
		return juego.getPuntuacion();
	}
	
	public int getTiradas() {
		return juego.getTiradas();
	}
	
	public int getDim() {
		return Tablero.DIM;
	}
	
	public String getEndMessage() {
		if (juego.getPuntuacion() == 0) {
			return "�Qu� mala suerte!\nEst� vez has perdido, no hay premio para ti.\n�Suerte para la pr�xima!";
		}
		else if (juego.getJugada() == 1) {
			return "�Has ganado!\nHas conseguido " + getPuntuacion() + " puntos cazando un rat�n simple, nada mal.";
		}
		else {
			return "�Genial!\nHas conseguido " + getPuntuacion() + " puntos cazando y encima has cazado un rat�n doble, �Enhorabuena!";
		}
	}
	
	public Premio[] getCatalogo() {
		return catalogo.getCatalogo();
	}
	
	public String getMensajePremio(Premio premio) {
		if (premio.getPuntos() > getPuntuacion()) {
			return "No tienes puntos suficientes para obtener ese premio";
		}
		return "Tu premio elegido es: " + premio.getNombre() +"\n �Hasta pronto!";
	}
}
