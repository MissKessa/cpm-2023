package uo.cpm.examen.model;

public class Premio {
	private String nombre;
	private int puntos;
	public Premio(String nombre, int puntos) {
		this.nombre = nombre;
		this.puntos = puntos;
	}
	public String getNombre() {
		return nombre;
	}
	public int getPuntos() {
		return puntos;
	}
	@Override
	public String toString() {
		return nombre + " - " + puntos;
	}
}
