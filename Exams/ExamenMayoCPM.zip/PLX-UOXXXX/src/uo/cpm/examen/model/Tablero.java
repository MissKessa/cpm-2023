package uo.cpm.examen.model;

public class Tablero {
	private int[] tablero;
	public static int DIM = 9;

	public Tablero() {
		generarTablero();
	}

	private void generarTablero() {
		inicializar();
		for (int i = 0; i < 3; i++) {
			colocarRaton(1);  /* colocamos un rat�n simple */
			colocarRaton(2);  /* colocamos un rat�n doble */
		}
		mostrarConsola();
	}

	private void inicializar() {
		tablero = new int[DIM];
		for (int i = 0; i < DIM; i++) {
			tablero[i] = 0;   /* Inicialmente todo el tablero se llena de gatos */
		}
	}

	private void colocarRaton(int valor) {
		int posicion = buscarHueco();
		tablero[posicion] = valor;
	}

	private int buscarHueco() {
		int pos;
		do {
			pos = (int) (Math.random() * DIM);
		} while (tablero[pos] != 0);
		return pos;
	}

	private void mostrarConsola() {
		for (int i = 0; i < DIM; i++) {
			System.out.print(tablero[i] + " ");
		}
		System.out.println("");
	}
	
	public int descubrirCasilla(int casilla) {
		return tablero[casilla];
	}
}
