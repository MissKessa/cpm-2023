package uo.cpm.examen.model;

import uo.cpm.examen.util.FileUtil;

public class Catalogo {
	private Premio[] catalogo;

	public Catalogo() {
		this.catalogo = FileUtil.loadFile();
	}

	public Premio[] getCatalogo() {
		return catalogo;
	}
}
