package uo.cpm.examen.model;

public class Juego {
	private Tablero tablero;
	private int tiradas;
	private int tirada1;
	private int tirada2;
	private int puntuacion;
	private int jugada;
	
	public Juego() {
		inicializar();
	}
	
	public void inicializar() {
		tablero = new Tablero();
		tiradas = 2;
		tirada1 = -1;
		tirada2 = -1;
		jugada = -1;
		puntuacion = ((int) (Math.random() * 100))+1;
	}
	
	public int descubrirCasilla(int i) {
		if (tirada1 == -1) {
			tirada1 = tablero.descubrirCasilla(i);
			tiradas--;
			return tirada1;
		}
		else {
			tirada2 = tablero.descubrirCasilla(i);
			tiradas--;
			if (tirada1 != tirada2 && tirada1+tirada2 < 3) {
				if (tirada1 + tirada2 == 1) {
					puntuacion *= 2;
					jugada = 1;
				}
				else {
					puntuacion *= 5;
					jugada = 2;
				}
			}
			else {
				puntuacion = 0;
			}
		}
		return tirada2;
	}
	
	public int getPuntuacion() {
		return puntuacion;
	}
	
	public int getTiradas() {
		return tiradas;
	}
	
	public Tablero getTablero() {
		return tablero;
	}
	
	public int getJugada() {
		return jugada;
	}
	
}
