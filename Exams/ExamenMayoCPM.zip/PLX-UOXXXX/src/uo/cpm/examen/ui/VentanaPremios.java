package uo.cpm.examen.ui;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import uo.cpm.examen.model.Premio;

import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.AbstractListModel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class VentanaPremios extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private VentanaPrincipal vp;
	private JScrollPane scpPremios;
	private JList<Premio> lstPremios;
	private JTextField txPuntos;
	private JLabel lbPuntuacion;
	private JLabel lbPremios;
	private JButton btConfirmar;
	private JLabel lbPremio;


	public VentanaPremios(VentanaPrincipal vp) {
		this.vp = vp;
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPremios.class.getResource("/img/Gato.png")));
		setTitle("Gato y Rat\u00F3n: Premios");
		setModal(true);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 528, 322);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getScpPremios());
		contentPane.add(getTxPuntos());
		contentPane.add(getLbPuntuacion());
		contentPane.add(getLbPremios());
		contentPane.add(getBtConfirmar());
		contentPane.add(getLbPremio());
		setLocationRelativeTo(vp);
		getRootPane().setDefaultButton(getBtConfirmar());
	}
	private JScrollPane getScpPremios() {
		if (scpPremios == null) {
			scpPremios = new JScrollPane();
			scpPremios.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			scpPremios.setBounds(153, 43, 181, 192);
			scpPremios.setViewportView(getLstPremios());
		}
		return scpPremios;
	}
	@SuppressWarnings("serial")
	private JList<Premio> getLstPremios() {
		if (lstPremios == null) {
			lstPremios = new JList<Premio>();
			lstPremios.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					int i = lstPremios.getSelectedIndex();
					String img = lstPremios.getModel().getElementAt(i).getNombre()+".png";
					getLbPremio().setIcon(new ImageIcon(VentanaPremios.class.getResource("/img/"+img)));
				}
			});
			lstPremios.setFont(new Font("Arial", Font.PLAIN, 14));
			lstPremios.setModel(new AbstractListModel<Premio>() {
				Premio[] premios = vp.gr.getCatalogo();
				public int getSize() {
					return premios.length;
				}
				public Premio getElementAt(int index) {
					return premios[index];
				}
			});
			lstPremios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		}
		return lstPremios;
	}
	private JTextField getTxPuntos() {
		if (txPuntos == null) {
			txPuntos = new JTextField();
			txPuntos.setHorizontalAlignment(SwingConstants.CENTER);
			txPuntos.setFont(new Font("Arial", Font.BOLD, 15));
			txPuntos.setEditable(false);
			txPuntos.setColumns(10);
			txPuntos.setBounds(416, 27, 86, 20);
			txPuntos.setText(vp.gr.getPuntuacion()+"");
		}
		return txPuntos;
	}
	private JLabel getLbPuntuacion() {
		if (lbPuntuacion == null) {
			lbPuntuacion = new JLabel("Puntuaci\u00F3n:");
			lbPuntuacion.setFont(new Font("Arial", Font.PLAIN, 14));
			lbPuntuacion.setBounds(416, 11, 75, 17);
		}
		return lbPuntuacion;
	}
	private JLabel getLbPremios() {
		if (lbPremios == null) {
			lbPremios = new JLabel("Premios:");
			lbPremios.setFont(new Font("Arial", Font.PLAIN, 14));
			lbPremios.setDisplayedMnemonic('p');
			lbPremios.setLabelFor(getLstPremios());
			lbPremios.setBounds(153, 18, 55, 17);
		}
		return lbPremios;
	}
	private JButton getBtConfirmar() {
		if (btConfirmar == null) {
			btConfirmar = new JButton("Confirmar");
			btConfirmar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int i = getLstPremios().getSelectedIndex();
					if (i < 0) return;
					Premio premio = getLstPremios().getModel().getElementAt(i);
					String mensaje = vp.gr.getMensajePremio(premio);
					JOptionPane.showMessageDialog(null, mensaje, "Gato y Rat�n: Selecci�n premio", JOptionPane.INFORMATION_MESSAGE);
					if (premio.getPuntos() <= vp.gr.getPuntuacion()) {
						dispose();
					}
				}
			});
			btConfirmar.setBounds(382, 249, 110, 23);
		}
		return btConfirmar;
	}
	private JLabel getLbPremio() {
		if (lbPremio == null) {
			lbPremio = new JLabel("");
			lbPremio.setBounds(372, 101, 130, 105);
		}
		return lbPremio;
	}
}
