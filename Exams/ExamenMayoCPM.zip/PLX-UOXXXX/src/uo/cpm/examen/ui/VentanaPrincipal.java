package uo.cpm.examen.ui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import uo.cpm.examen.service.GatoRaton;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.GridLayout;

import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.ImageIcon;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;
import java.awt.event.InputEvent;
import javax.swing.JSeparator;

public class VentanaPrincipal extends JFrame {


	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lbPuntuacion;
	private JTextField txPuntuacion;
	private JPanel pnTablero;
	GatoRaton gr;
	private JLabel lbTiradas;
	private JTextField txTiradas;
	private PulsarCasilla pc = new PulsarCasilla(this);
	private JMenuBar menuBar;
	private JMenu mnJuego;
	private JMenu mnAyuda;
	private JMenuItem mniNuevo;
	private JSeparator separator;
	private JMenuItem mniSalir;
	private JMenuItem mniContenidos;
	private JSeparator separator_1;
	private JMenuItem mniAcercaDe;
	private JLabel lbGato;
	private JLabel lbRaton;


	public VentanaPrincipal() {
		setResizable(false);
		gr = new GatoRaton();
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/Gato.png")));
		setTitle("Gato y Rat\u00F3n");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 946, 421);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLbPuntuacion());
		contentPane.add(getTxPuntuacion());
		contentPane.add(getPnTablero());
		contentPane.add(getLbTiradas());
		contentPane.add(getTxTiradas());
		contentPane.add(getLbGato());
		contentPane.add(getLbRaton());
		setLocationRelativeTo(null);
		cargaAyuda();
	}
	private JLabel getLbPuntuacion() {
		if (lbPuntuacion == null) {
			lbPuntuacion = new JLabel("Puntuaci\u00F3n:");
			lbPuntuacion.setFont(new Font("Arial", Font.PLAIN, 14));
			lbPuntuacion.setBounds(725, 34, 75, 17);
		}
		return lbPuntuacion;
	}
	private JTextField getTxPuntuacion() {
		if (txPuntuacion == null) {
			txPuntuacion = new JTextField();
			txPuntuacion.setEditable(false);
			txPuntuacion.setHorizontalAlignment(SwingConstants.CENTER);
			txPuntuacion.setFont(new Font("Arial", Font.BOLD, 15));
			txPuntuacion.setBounds(725, 50, 86, 20);
			txPuntuacion.setColumns(10);
			txPuntuacion.setText(gr.getPuntuacion()+"");
		}
		return txPuntuacion;
	}
	private JPanel getPnTablero() {
		if (pnTablero == null) {
			pnTablero = new JPanel();
			pnTablero.setBackground(Color.WHITE);
			pnTablero.setBounds(137, 241, 656, 109);
			pnTablero.setLayout(new GridLayout(1, 9, 2, 0));
			crearTablero();
			
		}
		return pnTablero;
	}
	
	private JButton crearCasilla(int i) {
		JButton bt = new JButton();
		bt.setActionCommand(i+"");
		bt.addActionListener(pc);
		bt.setToolTipText("Pulsa para descubrir la casilla");
		return bt;
	}
	
	private void crearTablero() {
		for (int i = 0; i < gr.getDim(); i++) {
			getPnTablero().add(crearCasilla(i));
		}
		validate();
	}
	private JLabel getLbTiradas() {
		if (lbTiradas == null) {
			lbTiradas = new JLabel("Tiradas restantes:");
			lbTiradas.setFont(new Font("Arial", Font.PLAIN, 14));
			lbTiradas.setBounds(165, 34, 115, 17);
		}
		return lbTiradas;
	}
	private JTextField getTxTiradas() {
		if (txTiradas == null) {
			txTiradas = new JTextField();
			txTiradas.setHorizontalAlignment(SwingConstants.CENTER);
			txTiradas.setFont(new Font("Arial", Font.BOLD, 15));
			txTiradas.setEditable(false);
			txTiradas.setColumns(10);
			txTiradas.setBounds(165, 51, 86, 20);
			txTiradas.setText(gr.getTiradas()+"");
		}
		return txTiradas;
	}
	
	private void habilitarTablero(boolean estado) {
		for (int i = 0; i < gr.getDim(); i++) {
			((JButton) getPnTablero().getComponent(i)).setEnabled(estado);
		}
	}
	
	private void inicializar() {
		gr.inicializar();
		
		for (int i = 0; i < gr.getDim(); i++) {
			((JButton) getPnTablero().getComponent(i)).setIcon(null);
			((JButton) getPnTablero().getComponent(i)).setDisabledIcon(null);
			((JButton) getPnTablero().getComponent(i)).setEnabled(true);			
		}
		getTxPuntuacion().setText(gr.getPuntuacion()+"");
		getTxTiradas().setText(gr.getTiradas()+"");
	}
	
	class PulsarCasilla implements ActionListener {
		
		private VentanaPrincipal vp;
		
		public PulsarCasilla(VentanaPrincipal vp) {
			this.vp = vp;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			procesaCasilla(e);
		}

		private void procesaCasilla(ActionEvent e) {
			JButton bt = ((JButton) e.getSource());
			int tipo = gr.descubrirCasilla(Integer.parseInt(bt.getActionCommand()));
			String imgPath = "/img/";
			switch(tipo) {
				case 0:
					imgPath += "Gato.png";
					break;
				case 1:
					imgPath += "Raton1.png";
					break;
				case 2:
					imgPath += "Raton2.png";
					break;
			}
			
			bt.setDisabledIcon(new ImageIcon(VentanaPrincipal.class.getResource(imgPath)));
			bt.setIcon(new ImageIcon(VentanaPrincipal.class.getResource(imgPath)));
			bt.setEnabled(false);
			getTxTiradas().setText(gr.getTiradas()+"");
			getTxPuntuacion().setText(gr.getPuntuacion()+"");
			
			if (gr.getTiradas() == 0) {
				habilitarTablero(false);
				JOptionPane.showMessageDialog(null, gr.getEndMessage(), "Gato y Rat�n: Resultado", JOptionPane.INFORMATION_MESSAGE);
				if (gr.getPuntuacion() > 0) {
					VentanaPremios vPremios = new VentanaPremios(vp);
					vPremios.setVisible(true);
				}
				inicializar();
			}
		}
	}
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnJuego());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}
	private JMenu getMnJuego() {
		if (mnJuego == null) {
			mnJuego = new JMenu("Juego");
			mnJuego.setMnemonic('j');
			mnJuego.add(getMniNuevo());
			mnJuego.add(getSeparator());
			mnJuego.add(getMniSalir());
		}
		return mnJuego;
	}
	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('a');
			mnAyuda.add(getMniContenidos());
			mnAyuda.add(getSeparator_1());
			mnAyuda.add(getMniAcercaDe());
		}
		return mnAyuda;
	}
	private JMenuItem getMniNuevo() {
		if (mniNuevo == null) {
			mniNuevo = new JMenuItem("Nuevo");
			mniNuevo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					inicializar();
				}
			});
			mniNuevo.setMnemonic('n');
			mniNuevo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
		}
		return mniNuevo;
	}
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	private JMenuItem getMniSalir() {
		if (mniSalir == null) {
			mniSalir = new JMenuItem("Salir");
			mniSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			mniSalir.setMnemonic('s');
		}
		return mniSalir;
	}
	private JMenuItem getMniContenidos() {
		if (mniContenidos == null) {
			mniContenidos = new JMenuItem("Contenidos");
			mniContenidos.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0));
			mniContenidos.setMnemonic('c');
		}
		return mniContenidos;
	}
	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
	private JMenuItem getMniAcercaDe() {
		if (mniAcercaDe == null) {
			mniAcercaDe = new JMenuItem("Acerca de");
			mniAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mostrarAcercaDe();
				}
			});
			mniAcercaDe.setMnemonic('d');
		}
		return mniAcercaDe;
	}
	
	private void cargaAyuda(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();
		   hb.initPresentation();

		   hb.enableHelpKey(getRootPane(),"alias html introduccion", hs);
		   hb.enableHelpOnButton(getMniContenidos(), "introduccion", hs);
		 }
	private JLabel getLbGato() {
		if (lbGato == null) {
			lbGato = new JLabel("");
			lbGato.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Gato.png")));
			lbGato.setBounds(377, 80, 95, 95);
		}
		return lbGato;
	}
	private JLabel getLbRaton() {
		if (lbRaton == null) {
			lbRaton = new JLabel("");
			lbRaton.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Raton1.png")));
			lbRaton.setBounds(482, 80, 95, 95);
		}
		return lbRaton;
	}
	
	private void mostrarAcercaDe() {
		JOptionPane.showMessageDialog(this, "Hugo Fern�ndez Rodr�guez\nUO289157", "Acerca de", JOptionPane.INFORMATION_MESSAGE);
	}
}
