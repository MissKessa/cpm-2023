package uo.cpm.examen.util;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import uo.cpm.examen.model.Premio;



public class FileUtil {
	// ADAPTAR PARA LOS DATOS IMPLEMENTADOS EN EL EXAMEN
	
// M�todo que lee un fichero y lo carga en una lista
public static Premio[] loadFile () {
	   String linea;
	   String[] datosArticulo= null;
	   String nombreFicheroEntrada = "files/premios.dat";
	   List<Premio> listaCatalogo = new ArrayList<Premio>();
	   try {
	    	   BufferedReader fichero = new BufferedReader(new FileReader(nombreFicheroEntrada));
	    		while (fichero.ready()) {
	    			linea = fichero.readLine();
	    			datosArticulo = linea.split("-");
	    			listaCatalogo.add(new Premio(datosArticulo[0],Integer.parseInt(datosArticulo[1])));
	    		}
	    		fichero.close();
	    }
	    catch (FileNotFoundException fnfe) {
	      System.out.println("El archivo no se ha encontrado.");
	    }
	    catch (IOException ioe) {
	      new RuntimeException("Error de entrada/salida.");
	    }
	   return listaCatalogo.toArray(Premio[]::new);
	   }
}
